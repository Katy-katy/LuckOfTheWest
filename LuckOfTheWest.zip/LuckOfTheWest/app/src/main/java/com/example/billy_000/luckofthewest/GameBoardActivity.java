package com.example.billy_000.luckofthewest;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by billy_000 on 7/6/2016.
 */
public class GameBoardActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_board);
    }


}
