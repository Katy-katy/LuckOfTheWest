package com.noahdavidson.luckofthewest;

import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.w3c.dom.Text;

/**
 * Created by noahdavidson on 7/6/16.
 */
public class GameBoardActivity extends AppCompatActivity {

    int score = 100;
    int day = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gameboard);

        TextView dayText = (TextView)findViewById(R.id.Day);
        TextView scoreText = (TextView)findViewById(R.id.Score);
        Button schoolButton = (Button)findViewById(R.id.schoolButton);
        Button barButton = (Button)findViewById(R.id.barButton);
        Button miningbutton = (Button)findViewById(R.id.miningButton);
        Button bankButton = (Button)findViewById(R.id.bankButton);

        // GET CUSTOM FONT
        Typeface customFont = Typeface.createFromAsset(getAssets(), "fonts/westernfonts.ttf");

        // set day text font
        dayText.setTypeface(customFont);

        // set score text font
        scoreText.setTypeface(customFont);

        // SET ALL buttons' FONT
        schoolButton.setTypeface(customFont);
        barButton.setTypeface(customFont);
        miningbutton.setTypeface(customFont);
        bankButton.setTypeface(customFont);

        // Set the strings for score and day on the screen
        scoreText.setText("$ " + String.valueOf(score));
        dayText.setText("Day " + String.valueOf(day));

    }

    public void startMiningGame(View view) {
        Intent intent = new Intent(this, MiningActivity.class);
        startActivity(intent);
    }
}
