package com.noahdavidson.wildwestgame;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by noahdavidson on 7/6/16.
 */
public class GameBoardActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_board);
    }

    @Override
    protected void onDestroy(){
        super.onDestroy();
    }

}
